圆角：https://developer.mozilla.org/zh-CN/docs/Web/CSS/border-radius
阴影：https://developer.mozilla.org/zh-CN/docs/Web/CSS/box-shadow
线性渐变：https://developer.mozilla.org/zh-CN/docs/Web/CSS/repeating-linear-gradient
动画：https://developer.mozilla.org/zh-CN/docs/Web/CSS/animation
